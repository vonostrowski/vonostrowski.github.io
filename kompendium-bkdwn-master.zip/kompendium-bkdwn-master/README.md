This is the new multi-platform version of the guidelines (Kompendium) for students in mathematics education that the mathematics education working group at the Department 03 of the University of Bremen has previously published as a PDF. It is authored by Thomas Janßen, my contact information is given in this Github profile.

Work is always in progress. You can find the preview of the next version of the Kompendium at https://janssent.github.io/kompendium-bkdwn/. A formally published version is available at the homepage of the AG Didaktik (http://www.math.uni-bremen.de/didaktik/).

You may use the Kompendium as an open educational resource and edit your own version with R Markdown and **bookdown** (https://github.com/rstudio/bookdown). Please see the page "[Get Started](https://bookdown.org/yihui/bookdown/get-started.html)" at https://bookdown.org/yihui/bookdown/ for an introduction.
